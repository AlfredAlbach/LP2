﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {

        double raio, altura, volume; //variaveis globais **


        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura é inválidaa!! O programa é limitado. ");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("O raio é invalidooh");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text,out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura é invalidaah!");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio,2)*altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtRaio.Text, out raio) || raio <=0)
            {
                MessageBox.Show("Raio é inválido, o programa é limitado. ");
            }
           /* else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("O raio tem que ser maior que 0. Seu burrão.");
                }
                else
                {

                }
            } */


        }
    }
}
