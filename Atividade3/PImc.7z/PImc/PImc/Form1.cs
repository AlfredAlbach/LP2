﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
               if (peso > 0 && altura > 0)
                {
                    double imc = peso / (altura * altura);
                    MessageBox.Show("Seu imc é "+ imc.ToString("F2"));
                    txtIMC.Text = imc.ToString("F2");
                    imc = Math.Round(imc, 1);
                    if (imc < 18.5)
                    txtResultadoIMC.Text = "Da pura Magreza";
                    else if (imc < 25)
                    txtResultadoIMC.Text = "Normal";
                    else if (imc < 30)
                    txtResultadoIMC.Text = "de Sobre Peso";
                    else if (imc < 40)
                    txtResultadoIMC.Text = "de obesidade";
                    else
                    txtResultadoIMC.Text = "Extremamente obeso"; 
                } else
                {
                    MessageBox.Show("Sua entrada de valores é inválida! Tem que ser números possitivos");
                }

            }
            else
            {
                MessageBox.Show("Digite apenas números seu burro do caralho!!!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();   
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
            txtResultadoIMC.Clear();
        }

        private void ResultadoIMC_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
