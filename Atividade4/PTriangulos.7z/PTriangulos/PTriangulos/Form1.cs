﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeTriãngulo
{
    public partial class Form1 : Form
    {
        double lado1,lado2,lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtALado1.Clear();
            txtBLado2.Clear();
            txtBLado3.Clear();
         /*   txtResultado.Clear();
            txt2Resultado.Clear(); */
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Font = new Font("Arial", 8);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();    
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtALado1.Text, out lado1) &&
                double.TryParse(txtBLado2.Text, out lado2) && 
                double.TryParse(txtBLado3.Text, out lado3))

                if (lado1 > 0 && lado2 > 0 && lado3 > 0)
                {
                    if (Math.Abs(lado2 - lado3) < lado1 && lado1 < (lado2 + lado3) &&
                        Math.Abs(lado1 - lado3) < lado2 && lado2 < (lado1 + lado3) &&
                        Math.Abs(lado1 - lado2) < lado3 && lado3 < (lado1 + lado2))
                    {

                        txtResultado.Text = "É um triangulo";

                        if (lado1 == lado2 && lado2 == lado3)
                            txt2Resultado.Text = "Equilatero";

                        else if ((lado1 == lado2 && lado2 != lado3 && lado1 != lado3) ||
                                 (lado2 == lado3 && lado2 != lado1 && lado3 != lado1) ||
                                 (lado3 == lado1 && lado3 != lado2 && lado1 != lado2))

                            txt2Resultado.Text = "Isósceles";

                        else
                            txt2Resultado.Text = "Escaleno";

                    }
                } 
                else
                    MessageBox.Show("Entrada de valores iválidas. Tem que ser numeros positivos ou maiores que 0");
                



        }
    }
}
