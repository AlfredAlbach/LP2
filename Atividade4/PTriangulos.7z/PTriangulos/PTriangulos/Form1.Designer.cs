﻿namespace AtividadeTriãngulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblLado1 = new System.Windows.Forms.Label();
            this.lblLado2 = new System.Windows.Forms.Label();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.lblRsultado = new System.Windows.Forms.Label();
            this.txtALado1 = new System.Windows.Forms.MaskedTextBox();
            this.txtResultado = new System.Windows.Forms.MaskedTextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtBLado2 = new System.Windows.Forms.MaskedTextBox();
            this.txtBLado3 = new System.Windows.Forms.MaskedTextBox();
            this.lbl2Resultado = new System.Windows.Forms.Label();
            this.txt2Resultado = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(153, 280);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(209, 23);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.Location = new System.Drawing.Point(38, 73);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(48, 16);
            this.lblLado1.TabIndex = 1;
            this.lblLado1.Text = "Lado 1";
            // 
            // lblLado2
            // 
            this.lblLado2.AutoSize = true;
            this.lblLado2.Location = new System.Drawing.Point(38, 128);
            this.lblLado2.Name = "lblLado2";
            this.lblLado2.Size = new System.Drawing.Size(48, 16);
            this.lblLado2.TabIndex = 2;
            this.lblLado2.Text = "Lado 2";
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.Location = new System.Drawing.Point(38, 184);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(48, 16);
            this.lblLado3.TabIndex = 3;
            this.lblLado3.Text = "Lado 3";
            // 
            // lblRsultado
            // 
            this.lblRsultado.AutoSize = true;
            this.lblRsultado.Location = new System.Drawing.Point(38, 350);
            this.lblRsultado.Name = "lblRsultado";
            this.lblRsultado.Size = new System.Drawing.Size(69, 16);
            this.lblRsultado.TabIndex = 4;
            this.lblRsultado.Text = "Resultado";
            // 
            // txtALado1
            // 
            this.txtALado1.Location = new System.Drawing.Point(153, 70);
            this.txtALado1.Name = "txtALado1";
            this.txtALado1.Size = new System.Drawing.Size(209, 22);
            this.txtALado1.TabIndex = 1;
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(153, 350);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(209, 22);
            this.txtResultado.TabIndex = 8;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(287, 242);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(287, 23);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Sair";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtBLado2
            // 
            this.txtBLado2.Location = new System.Drawing.Point(153, 128);
            this.txtBLado2.Name = "txtBLado2";
            this.txtBLado2.Size = new System.Drawing.Size(209, 22);
            this.txtBLado2.TabIndex = 2;
            // 
            // txtBLado3
            // 
            this.txtBLado3.Location = new System.Drawing.Point(153, 184);
            this.txtBLado3.Name = "txtBLado3";
            this.txtBLado3.Size = new System.Drawing.Size(209, 22);
            this.txtBLado3.TabIndex = 3;
            // 
            // lbl2Resultado
            // 
            this.lbl2Resultado.AutoSize = true;
            this.lbl2Resultado.Location = new System.Drawing.Point(12, 402);
            this.lbl2Resultado.Name = "lbl2Resultado";
            this.lbl2Resultado.Size = new System.Drawing.Size(114, 16);
            this.lbl2Resultado.TabIndex = 13;
            this.lbl2Resultado.Text = "Tipo de triângulo :";
            this.lbl2Resultado.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt2Resultado
            // 
            this.txt2Resultado.Enabled = false;
            this.txt2Resultado.Location = new System.Drawing.Point(153, 402);
            this.txt2Resultado.Name = "txt2Resultado";
            this.txt2Resultado.Size = new System.Drawing.Size(209, 22);
            this.txt2Resultado.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AtividadeTriãngulo.Properties.Resources.minion;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(412, 450);
            this.Controls.Add(this.txt2Resultado);
            this.Controls.Add(this.lbl2Resultado);
            this.Controls.Add(this.txtBLado3);
            this.Controls.Add(this.txtBLado2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtALado1);
            this.Controls.Add(this.lblRsultado);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.lblLado2);
            this.Controls.Add(this.lblLado1);
            this.Controls.Add(this.btnCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.Label lblLado2;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.Label lblRsultado;
        private System.Windows.Forms.MaskedTextBox txtALado1;
        private System.Windows.Forms.MaskedTextBox txtResultado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MaskedTextBox txtBLado2;
        private System.Windows.Forms.MaskedTextBox txtBLado3;
        private System.Windows.Forms.Label lbl2Resultado;
        private System.Windows.Forms.MaskedTextBox txt2Resultado;
    }
}

