﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                Numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "O seu Número 2 é invalidoooo!");
                txtNumero2.Focus();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                errorProvider2.SetError(txtNumero2, "Seu numero não pode ser dividido por 0 seu anta");
                txtNumero2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtNumero2, "");
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();

        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Text = null;
            txtNumero1.Text = null;
            txtNumero2.Text = null;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você quer sair do aplicativo mesmo? Eu sei aonde voce mora através do seu IP",
                            "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { Close(); }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                errorProvider1.SetError(txtNumero1, "O seu número 1 está inválido seu burro!");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }
    }
}
